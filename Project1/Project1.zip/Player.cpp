#include "Player.h"

void setPlayer()
{
	patrol.rec.x = GetScreenWidth() / 8 * 6;
	patrol.rec.y = GetScreenHeight() / 4 * 1;
	patrol.rec.width = 30;
	patrol.rec.height = 20;
	patrol.speed.x = 200;
	patrol.speed.y = 200;
	patrol.gravity.x = 200;
	patrol.gravity.y = 200;
	patrol.isJumping = false;
	patrol.canCollide = true;
	patrol.lives = 4;
}

void setBullet()
{
	bullet.rec.x = patrol.rec.x;
	bullet.rec.y = patrol.rec.y;
	bullet.rec.width = 5;
	bullet.rec.height = 5;
	bullet.bulletActive = false;
}

void playerInput()
{
	if (IsKeyDown(KEY_SPACE) && !patrol.isJumping)
	{
		patrol.speed.y = -600;
		patrol.isJumping = true;
	}
	if (IsKeyDown(KEY_LEFT))
	{
		patrol.speed.x = -200;

	}
	else if (IsKeyDown(KEY_RIGHT))
	{
		patrol.speed.x = 200;

	}
	else if (!patrol.isJumping)
	{
		patrol.speed.x = 0;
	}
}

void playerMovement()
{
	patrol.rec.x += patrol.speed.x * GetFrameTime();
	patrol.rec.y += patrol.speed.y * GetFrameTime();

	if (patrol.isJumping)
	{
		patrol.speed.y += 1500 * GetFrameTime();
	}

	if (patrol.rec.y > GetScreenHeight() / 8 * 6)
	{
		patrol.speed.y = 0;
		patrol.isJumping = false;
	}

	if (patrol.rec.x < 0)
	{
		patrol.rec.x = 0;
	}
	if (patrol.rec.x > GetScreenWidth() - patrol.rec.width)
	{
		patrol.rec.x = GetScreenWidth() - patrol.rec.width;
	}
}



void loseCondition(int& screen)
{
	if (patrol.lives <= 0 && patrol.canCollide == true)
	{
		screen = SCREENS::MENU;
	}
}