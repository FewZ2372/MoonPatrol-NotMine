#pragma once
#include "raylib.h"
#include "Menu.h"

struct Player
{
	Rectangle rec;

	Vector2 speed;
	Vector2 gravity;

	bool isJumping;
	bool bulletActive;
	bool canCollide;

	int lives;
};
extern Player patrol;
extern Player bullet;

void setPlayer();
void setBullet();
void playerInput();
void playerMovement();
void hasCollided();