#include "Parallax.h"

void setParallax()
{
	for (int i = 0; i < 4; i++)
	{
		parallax[i].rec.x = GetScreenWidth();
		parallax[i].rec.y = 0;
		parallax[i].rec.width = 1280;
	}

	parallax[0].rec.height = 900;
	parallax[1].rec.height = 720;
	parallax[2].rec.height = 720;
	parallax[3].rec.height = 720;

	scrollingBack = -100;
	scrollingSemiBack = -150;
	scrollingMid = -220;
	scrollingFore = 20;
}

void moveParallax(int& screen, Texture2D& background, Texture2D& semibackground, Texture2D& midground, Texture2D& foreground)
{
//	if (scrollingBack <= -parallax[0].rec.width)scrollingBack = 0.0f;
//	if (scrollingSemiBack <= -parallax[1].rec.width)scrollingSemiBack = 0.0f;
//	if (scrollingMid <= -parallax[2].rec.width) scrollingMid = 0.0f;
//	if (scrollingFore <= -parallax[3].rec.width) scrollingFore = 0;

	if (screen == GAME)
	{

		DrawTextureEx(background, { parallax[0].rec.x, parallax[0].rec.y }, 0.0f, 2.0f, WHITE);
		//DrawTextureEx(background, Vector2 { background.width* 2 + scrollingBack.x, scrollingBack.y }, 0.0f, 2.0f, WHITE);

		DrawTextureEx(semibackground, { parallax[1].rec.x, parallax[1].rec.y }, 0.0f, 2.0f, WHITE);
		/*DrawTextureEx(semibackground, (Vector2) { scrollingBack, 20 }, 0.0f, 2.0f, WHITE);
		DrawTextureEx(semibackground, (Vector2) { semibackground.width * 2 + scrollingBack, 20 }, 0.0f, 2.0f, WHITE);*/

		DrawTextureEx(midground, { parallax[2].rec.x, parallax[2].rec.y }, 0.0f, 2.0f, WHITE);
		/*DrawTextureEx(midground, (Vector2) { scrollingMid, 20 }, 0.0f, 2.0f, WHITE);
		DrawTextureEx(midground, (Vector2) { midground.width * 2 + scrollingMid, 20 }, 0.0f, 2.0f, WHITE);*/

		DrawTextureEx(foreground, { parallax[3].rec.x, parallax[3].rec.y }, 0.0f, 2.0f, WHITE);

		if (bullet.bulletActive == true)
		{
			DrawRectangle(static_cast<int>(bullet.rec.x),
				static_cast<int>(bullet.rec.y),
				static_cast<int>(bullet.rec.width),
				static_cast<int>(bullet.rec.height),
				WHITE);
		}

		/*DrawTextureEx(foreground, (Vector2) { scrollingFore, 70 }, 0.0f, 2.0f, WHITE);
		DrawTextureEx(foreground, (Vector2) { foreground.width * 2 + scrollingFore, 70 }, 0.0f, 2.0f, WHITE);*/
		DrawRectangle(static_cast<int>(enemy.rec.x), static_cast<int>(enemy.rec.y), static_cast<int> (enemy.rec.width), static_cast<int> (enemy.rec.height), WHITE);

		DrawRectangle(static_cast<int>(obstacle.rec.x), static_cast<int>(obstacle.rec.y), static_cast<int> (obstacle.rec.width), static_cast<int> (obstacle.rec.height), WHITE);

		DrawRectangle(static_cast<int>(patrol.rec.x), static_cast<int>(patrol.rec.y), static_cast<int>(patrol.rec.width), static_cast<int>(patrol.rec.height), RED);

	}
}
