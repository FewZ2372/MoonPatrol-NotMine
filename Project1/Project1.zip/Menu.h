#pragma once
#include "raylib.h"
#include "Game.h"

enum  SCREENS
{
	MENU,
	GAME,
	CREDITS,
	EXIT
};

struct Menu
{
};

void DrawGame(int& screen, Texture2D& background, Texture2D& semibackground, Texture2D& midground, Texture2D& foreground);
void DrawCredits(int& screen);
void TextMenu();
void Menu(int& screen, Texture2D& background, Texture2D& semibackground, Texture2D& midground, Texture2D& foreground);
void DrawMenu(Rectangle game, Rectangle credits, Rectangle instruction);
void Credits(Rectangle credits, int& screen);
