#include "Game.h"

void setGame()
{
	game.pause = false;
	game.resetPause = false;
	game.exitGame = false;
	game.gameOver = false;

}

void Pause(bool& pause, int& screen, bool& resetPause)
{
	Rectangle caja_pausa = { static_cast<int>(GetScreenWidth()) / static_cast <float>(2) - 350, static_cast<int>(GetScreenHeight()) / static_cast <float>(2) - 90, 250, 100 };
	Rectangle volverMenu = { static_cast<int>(GetScreenWidth()) / static_cast <float>(2) + 100, static_cast<int>(GetScreenHeight()) / static_cast <float>(2) - 90,250, 100 };


	if (pause == true)
	{
		DrawRectangleRec(caja_pausa, PURPLE);
		DrawText("PAUSA", GetScreenWidth() / 2 - 280, GetScreenHeight() / 2 - 50, 30, WHITE);


		if (CheckCollisionPointRec(GetMousePosition(), caja_pausa))
		{
			DrawRectangleRec(caja_pausa, VIOLET);
			DrawText("PAUSA", GetScreenWidth() / 2 - 280, GetScreenHeight() / 2 - 50, 30, WHITE);

			if (IsMouseButtonDown(MOUSE_BUTTON_LEFT))
			{

				DrawRectangleRec(caja_pausa, DARKPURPLE);
				DrawText("PAUSA", GetScreenWidth() / 2 - 280, GetScreenHeight() / 2 - 50, 30, WHITE);
				pause = !pause;

			}

		}
		DrawRectangleRec(volverMenu, PURPLE);
		DrawText("VOLVER AL MENU", GetScreenWidth() / 2 + 110, GetScreenHeight() / 2 - 50, 26, WHITE);

		if (CheckCollisionPointRec(GetMousePosition(), volverMenu))
		{

			DrawRectangleRec(volverMenu, VIOLET);
			DrawText("VOLVER AL MENU", GetScreenWidth() / 2 + 110, GetScreenHeight() / 2 - 50, 26, WHITE);

			if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT))
			{

				DrawRectangleRec(volverMenu, DARKPURPLE);
				DrawText("VOLVER AL MENU", GetScreenWidth() / 2 + 110, GetScreenHeight() / 2 - 50, 26, WHITE);

				screen = MENU;
				resetPause = !resetPause;
			}

		}

	}

	if (IsKeyPressed('P') || IsKeyPressed('p') || IsKeyPressed(KEY_ESCAPE))
	{
		pause = !pause;

		//cout << pause << endl;
		//0 false
		//1 true
	}
}


void ExitGame(Rectangle exit, int& screen)
{
	if (CheckCollisionPointRec(GetMousePosition(), exit))
	{
		DrawRectangleRec(exit, VIOLET);
		DrawText("SALIR", GetScreenWidth() / 2 - 80, GetScreenHeight() / 2 + 200, 30, WHITE);

		if (IsMouseButtonDown(MOUSE_BUTTON_LEFT))
		{
			DrawRectangleRec(exit, DARKPURPLE);
			DrawText("SALIR", GetScreenWidth() / 2 - 80, GetScreenHeight() / 2 + 200, 30, WHITE);
			screen = EXIT;
		}
	}
}

void runGame(Rectangle game, int& screen)
{
	if (CheckCollisionPointRec(GetMousePosition(), game))
	{
		DrawRectangleRec(game, VIOLET);
		//DrawText("JUGAR", GetScreenWidth() / 2 - 80, GetScreenHeight() / 2 - 50, 30, WHITE);

		if (IsMouseButtonDown(MOUSE_BUTTON_LEFT))
		{
			screen = GAME;
			DrawRectangleRec(game, DARKPURPLE);
			//DrawText("JUGAR", GetScreenWidth() / 2 - 80, GetScreenHeight() / 2 - 50, 30, WHITE);
		}

	}
}

void Update(int& screen, bool& gameOver, Texture2D& background, Texture2D& semibackground, Texture2D& midground, Texture2D& foreground)
{
	hasCollided();
	enemyMovement();
	moveObstacle();
	playerInput();
	playerMovement();
	moveParallax(screen, background, semibackground, midground, foreground);

	if (bullet.bulletActive == true)
	{
		bullet.rec.y -= 400 * GetFrameTime();
	}

	if (bullet.rec.y <= 0)
	{

		bullet.bulletActive = false;
		bullet.rec.x = patrol.rec.x;
		bullet.rec.y = patrol.rec.y;
	}

}

void hasCollided()
{
	float currentTimer = 0;
	float targetTime = 10.0f;

	currentTimer += GetFrameTime();

	if (currentTimer >= targetTime)
	{
		patrol.canCollide = true;
		framesCounter = 0;
	}

	if (CheckCollisionRecs(patrol.rec, obstacle.rec) && patrol.canCollide == true)
	{
		patrol.canCollide = false;
		patrol.lives--;
	}
}

