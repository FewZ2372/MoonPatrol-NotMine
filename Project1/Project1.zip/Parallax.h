#pragma once
#include "raylib.h"
#include "Menu.h"
#include "Enemy.h"


struct Parallax
{
	Rectangle rec;
};

extern Parallax parallax[4];

extern float scrollingBack; //marsmountain
extern float scrollingSemiBack;//marsfar
extern float scrollingMid;//marsmid
extern float scrollingFore;//marsclose

void setParallax();
void moveParallax(int& screen, Texture2D& background, Texture2D& semibackground, Texture2D& midground, Texture2D& foreground);


